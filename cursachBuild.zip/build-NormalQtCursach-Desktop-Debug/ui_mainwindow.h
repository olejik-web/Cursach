/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout_2;
    QCustomPlot *plotWidget;
    QWidget *parametersWidget;
    QGridLayout *gridLayout_2;
    QFormLayout *parametersLayout;
    QLabel *x0Label;
    QDoubleSpinBox *x0SpinBox;
    QLabel *t0Label;
    QDoubleSpinBox *t0SpinBox;
    QLabel *hLabel;
    QDoubleSpinBox *hSpinBox;
    QLabel *nLabel;
    QSpinBox *nSpinBox;
    QPushButton *drawGraphButton;
    QHBoxLayout *differentionalEquationLayout;
    QSpacerItem *horizontalSpacer;
    QLabel *differentionalEquationLabel;
    QLineEdit *differentionalEquationLineEdit;
    QSpacerItem *horizontalSpacer2;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(618, 367);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        plotWidget = new QCustomPlot(centralWidget);
        plotWidget->setObjectName(QString::fromUtf8("plotWidget"));
        parametersWidget = new QWidget(plotWidget);
        parametersWidget->setObjectName(QString::fromUtf8("parametersWidget"));
        parametersWidget->setGeometry(QRect(420, 10, 161, 151));
        gridLayout_2 = new QGridLayout(parametersWidget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        parametersLayout = new QFormLayout();
        parametersLayout->setObjectName(QString::fromUtf8("parametersLayout"));
        parametersLayout->setHorizontalSpacing(1);
        parametersLayout->setVerticalSpacing(1);
        x0Label = new QLabel(parametersWidget);
        x0Label->setObjectName(QString::fromUtf8("x0Label"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(x0Label->sizePolicy().hasHeightForWidth());
        x0Label->setSizePolicy(sizePolicy);
        x0Label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        parametersLayout->setWidget(0, QFormLayout::LabelRole, x0Label);

        x0SpinBox = new QDoubleSpinBox(parametersWidget);
        x0SpinBox->setObjectName(QString::fromUtf8("x0SpinBox"));
        x0SpinBox->setDecimals(5);
        x0SpinBox->setMinimum(-10000.000000000000000);
        x0SpinBox->setMaximum(10000.000000000000000);
        x0SpinBox->setValue(-1.000000000000000);

        parametersLayout->setWidget(0, QFormLayout::FieldRole, x0SpinBox);

        t0Label = new QLabel(parametersWidget);
        t0Label->setObjectName(QString::fromUtf8("t0Label"));
        t0Label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        parametersLayout->setWidget(1, QFormLayout::LabelRole, t0Label);

        t0SpinBox = new QDoubleSpinBox(parametersWidget);
        t0SpinBox->setObjectName(QString::fromUtf8("t0SpinBox"));
        t0SpinBox->setDecimals(5);
        t0SpinBox->setMinimum(-10000.000000000000000);
        t0SpinBox->setMaximum(10000.000000000000000);
        t0SpinBox->setValue(5.000000000000000);

        parametersLayout->setWidget(1, QFormLayout::FieldRole, t0SpinBox);

        hLabel = new QLabel(parametersWidget);
        hLabel->setObjectName(QString::fromUtf8("hLabel"));
        hLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        parametersLayout->setWidget(2, QFormLayout::LabelRole, hLabel);

        hSpinBox = new QDoubleSpinBox(parametersWidget);
        hSpinBox->setObjectName(QString::fromUtf8("hSpinBox"));
        hSpinBox->setDecimals(5);
        hSpinBox->setMaximum(100.000000000000000);
        hSpinBox->setValue(0.010000000000000);

        parametersLayout->setWidget(2, QFormLayout::FieldRole, hSpinBox);

        nLabel = new QLabel(parametersWidget);
        nLabel->setObjectName(QString::fromUtf8("nLabel"));
        nLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        parametersLayout->setWidget(3, QFormLayout::LabelRole, nLabel);

        nSpinBox = new QSpinBox(parametersWidget);
        nSpinBox->setObjectName(QString::fromUtf8("nSpinBox"));
        nSpinBox->setMaximum(100000);
        nSpinBox->setValue(40000);

        parametersLayout->setWidget(3, QFormLayout::FieldRole, nSpinBox);


        gridLayout_2->addLayout(parametersLayout, 0, 0, 1, 1);

        drawGraphButton = new QPushButton(parametersWidget);
        drawGraphButton->setObjectName(QString::fromUtf8("drawGraphButton"));

        gridLayout_2->addWidget(drawGraphButton, 1, 0, 1, 1);


        horizontalLayout_2->addWidget(plotWidget);

        horizontalLayout_2->setStretch(0, 30);

        gridLayout->addLayout(horizontalLayout_2, 0, 0, 1, 2);

        differentionalEquationLayout = new QHBoxLayout();
        differentionalEquationLayout->setObjectName(QString::fromUtf8("differentionalEquationLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        differentionalEquationLayout->addItem(horizontalSpacer);

        differentionalEquationLabel = new QLabel(centralWidget);
        differentionalEquationLabel->setObjectName(QString::fromUtf8("differentionalEquationLabel"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(differentionalEquationLabel->sizePolicy().hasHeightForWidth());
        differentionalEquationLabel->setSizePolicy(sizePolicy1);
        differentionalEquationLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        differentionalEquationLayout->addWidget(differentionalEquationLabel);

        differentionalEquationLineEdit = new QLineEdit(centralWidget);
        differentionalEquationLineEdit->setObjectName(QString::fromUtf8("differentionalEquationLineEdit"));

        differentionalEquationLayout->addWidget(differentionalEquationLineEdit);

        horizontalSpacer2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        differentionalEquationLayout->addItem(horizontalSpacer2);

        differentionalEquationLayout->setStretch(0, 3);
        differentionalEquationLayout->setStretch(1, 1);
        differentionalEquationLayout->setStretch(2, 10);
        differentionalEquationLayout->setStretch(3, 3);

        gridLayout->addLayout(differentionalEquationLayout, 6, 1, 1, 1);

        gridLayout->setRowStretch(0, 1);
        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        x0Label->setText(QApplication::translate("MainWindow", "x0:", nullptr));
        t0Label->setText(QApplication::translate("MainWindow", "t0:", nullptr));
        hLabel->setText(QApplication::translate("MainWindow", "h:", nullptr));
        nLabel->setText(QApplication::translate("MainWindow", "n:", nullptr));
        drawGraphButton->setText(QApplication::translate("MainWindow", "\320\237\320\276\321\201\321\202\321\200\320\276\320\270\321\202\321\214 \320\263\321\200\320\260\321\204\320\270\320\272", nullptr));
        differentionalEquationLabel->setText(QApplication::translate("MainWindow", "x'(t):", nullptr));
        differentionalEquationLineEdit->setText(QApplication::translate("MainWindow", "(x-2sqrt(tx))/t", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
